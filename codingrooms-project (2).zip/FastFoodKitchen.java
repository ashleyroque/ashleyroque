import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io. *;

import java.io.FileOutputStream;
import java.io.PrintWriter;


/**
 *
 * @author Ashley Roque
 * University of North Carolina at Charlotte
 */

public class FastFoodKitchen {

    private ArrayList<BurgerOrder> orderList = new ArrayList<>(); //changed this

    private static int nextOrderNum = 1;

    FastFoodKitchen() {
        orderList.add(new BurgerOrder(3, 15, 4, 10, false, getNextOrderNum()));
        incrementNextOrderNum();
        orderList.add(new BurgerOrder(10, 10, 3, 3, true, getNextOrderNum()));
        incrementNextOrderNum();
        orderList.add(new BurgerOrder(1, 1, 1, 2, false, getNextOrderNum()));
        incrementNextOrderNum();
    }

    public static int getNextOrderNum() {
        return nextOrderNum;
    }

    private void incrementNextOrderNum() {
        nextOrderNum++;
    }

    public int addOrder(int ham, int cheese, int veggie, int soda, boolean toGo) {
        int orderNum = getNextOrderNum();
        orderList.add(new BurgerOrder(ham, cheese, veggie, soda, toGo, orderNum));
        incrementNextOrderNum();
        orderCallOut(orderList.get(orderList.size() - 1));
        return orderNum;

    }

    public boolean isOrderDone(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                return false;
            }
        }
        return true;
    }

    public boolean cancelOrder(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                orderList.remove(i);
                return true;
            }
        }
        return false;
    }

    public int getNumOrdersPending() {
        return orderList.size();
    }

    public boolean cancelLastOrder() {

        if (!orderList.isEmpty()) { 
            orderList.remove(orderList.size() - 1);
            return true;
        }

        return false;
    }

    private void orderCallOut(BurgerOrder order) {
        if (order.getNumCheeseburgers() > 0) {
            System.out.println(
                "You have " + order.getNumHamburger() + " hamburgers"
            );
        }
        if (order.getNumCheeseburgers() > 0) {
            System.out.println(
                "You have " + order.getNumCheeseburgers() + " cheeseburgers"
            );
        }
        if (order.getNumVeggieburgers() > 0) {
            System.out.println(
                "You have " + order.getNumVeggieburgers() + " veggieburgers"
            );
        }
        if (order.getNumSodas() > 0) {
            System.out.println("You have " + order.getNumSodas() + " sodas");
        }

    }

    public void completeSpecificOrder(int orderID) {
        for (int i = 0; i < orderList.size(); i++) {
            if (orderList.get(i).getOrderNum() == orderID) {
                System.out.println("Order number " + orderID + " is done!");
                if (orderList.get(i).isOrderToGo()) {
                    orderCallOut(orderList.get(i));
                }
                orderList.remove(i);
            }
        }

    }

    public void completeNextOrder() {
        int nextOrder = orderList.get(0).getOrderNum();
        completeSpecificOrder(nextOrder);

    }

    // Part 2
    public ArrayList<BurgerOrder> getOrderList() {
        return orderList;
    }

    public int findOrderSeq(int whatWeAreLookingFor) {
        for (int j = 0; j < orderList.size(); j++) {
            if (orderList.get(j).getOrderNum() == whatWeAreLookingFor) {
                return j;
            }
        }
        return -1;
    }


    public int findOrderBin(int orderID) {
        int left = 0;
        int right = orderList.size() - 1;
        while (left <= right) {
            int middle = ((left + right) / 2);
            if (orderID < orderList.get(middle).getOrderNum()) {
                right = middle - 1;
            } else if (orderID > orderList.get(middle).getOrderNum()) {
                left = middle + 1;
            } else {
                return middle;
            }
        }
        return -1;

    }
    public void selectionSort() {
        for (int i = 0; i < orderList.size() - 1; i++) {
            int minIndex = i;
            for (int k = i + 1; k < orderList.size(); k++) {
                if (orderList.get(minIndex).getTotalBurgers() > orderList.get(k).getTotalBurgers()) {
                    minIndex = k;
                }
            }
            BurgerOrder temp = orderList.get(i);
            orderList.set(i, orderList.get(minIndex));
            orderList.set(minIndex, temp);
        }
    }

    public void insertionSort() {
        for (int j = 1; j < orderList.size(); j++) {
            BurgerOrder temp = orderList.get(j);
            int possibleIndex = j;
            while (
                possibleIndex > 0 && temp.getTotalBurgers() < orderList.get(possibleIndex - 1).getTotalBurgers()
            ) {
                orderList.set(possibleIndex, orderList.get(possibleIndex - 1));
                possibleIndex--;
            }
            orderList.set(possibleIndex, temp);
        }
    }

  
    public void ordersLoaded(String burgerOrders) {
        String line = "";
        try(Scanner scnr = new Scanner(new File(burgerOrders))) {
            if (scnr.hasNextLine()) {
                scnr.nextLine();
            }
            while (scnr.hasNextLine()) {
                line = scnr.nextLine();
                String[] variables = line.split(",");

                int orderNum = Integer.parseInt(variables[0]);
                int numHamburgers = Integer.parseInt(variables[1]);
                int numCheeseburgers = Integer.parseInt(variables[2]);
                int numVeggieburgers = Integer.parseInt(variables[3]);
                int numSodas = Integer.parseInt(variables[4]);
                boolean orderToGo = variables[5].equals("true");

                orderList.add(new BurgerOrder(
                    numHamburgers,
                    numCheeseburgers,
                    numVeggieburgers,
                    numSodas,
                    orderToGo,
                    orderNum
                ));
            }
        } catch (Exception e) {
            System.out.println("Error. Orders cannot be loaded. \n" + e.getMessage());
        }
    }


    public void endReport(String endOfDayReport) {
        int totalHamburgers = 0;
        int totalCheeseburgers = 0;
        int totalVeggieburgers = 0;
        int totalSodas = 0;
        int totalOrdersToGo = 0;

        FileWriter fs;
        try {
            fs = new FileWriter(endOfDayReport);

            PrintWriter wtr = new PrintWriter(fs);
            wtr.println("________End of Day Sales Report________\n");
            wtr.println(
                "Total Orders: " + orderList.size() + "\nTotal Hamburgers Sold: " +
                totalHamburgers + "\nTotal Cheeseburgers Sold: " +
                totalCheeseburgers + "\nTotal Veggieburgers: " +
                totalVeggieburgers + "\nTotal Sodas: " + totalSodas +
                "\nTotal Orders To Go: " + totalOrdersToGo + "\n"
            );
            wtr.println(
                "orderID, Hamburgers, Cheeseburgers, Veggieburgers, Sodas, To Go\n"
            );

            for (BurgerOrder orders : orderList) {
                totalHamburgers += orders.getNumHamburger();
                totalCheeseburgers += orders.getNumCheeseburgers();
                totalVeggieburgers += orders.getNumVeggieburgers();
                totalSodas += orders.getNumSodas();
                if (orders.isOrderToGo()) {
                    totalOrdersToGo++;
                }
                wtr.println("________Today's Orders________\n");
                wtr.println(
                    orders.getOrderNum() + ", " + orders.getNumHamburger() + ", " + orders.getNumCheeseburgers() +
                    ", " + orders.getNumVeggieburgers() + ", " + orders.getNumSodas() + ", " +
                    orders.isOrderToGo() + "\n"
                );
            }

            System.out.println(
                "End of day report has been generated: " + endOfDayReport
            );
            fs.close();
            wtr.close();
        } catch (FileNotFoundException e) {
            System.out.println(
                "The " + endOfDayReport + " file was not found."
            );
        } catch (IOException e) {
            System.out.println("Error getting the end-of-day report: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error generating the end-of-day report: " + e.getMessage());
        }

    }

    public void updatedOrder(String burgerOrders2) {
        try(PrintWriter wtr = new PrintWriter(new FileWriter(burgerOrders2))) {
            wtr.println(
                "orderID, Hamburgers, Cheeseburgers, Veggieburgers, Sodas, To Go\n"
            );
            for (BurgerOrder orders : orderList) {
                wtr.println(
                    orders.getOrderNum() + ", " + orders.getNumHamburger() + ", " + orders.getNumCheeseburgers() +
                    ", " + orders.getNumVeggieburgers() + ", " + orders.getNumSodas() + ", " +
                    orders.isOrderToGo() + "\n"
                );
            }
            System.out.println(
                "Updated orders can be located here: " + burgerOrders2
            );

        } catch (FileNotFoundException e) {
            System.out.println(
                "The " + burgerOrders2 + " file was not found."
            );
        } catch (IOException e) {
            System.out.println("Error getting the end-of-day report: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error generating the end-of-day report: " + e.getMessage());
        }


    }

}